from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from django.template import loader
from .models import Contact
from .models import Design
from .models import Category
from .models import Cart
from .models import Wishlist
from .models import Order
from .models import Registration
from .models import Adminregistration
from .models import Notification,Notification1
import datetime



# Create your views here.

def index(request):
    categories = Category.objects.all().values()
    context ={
        'categories':categories
    }
    template = loader.get_template("index.html")
    return HttpResponse(template.render(context,request))

def about(request):
    categories = Category.objects.all().values()
    context ={
        'categories':categories,
    }
    template = loader.get_template("about.html")
    return HttpResponse(template.render(context,request))


def contact(request):
    categories = Category.objects.all().values()
    context ={
        'categories':categories,
    }
    if request.method == 'POST':
        cname = request.POST["contact_name"]
        cemail = request.POST["contact_email"]
        cmsg = request.POST["contact_message"]

        con = Contact(
            con_name = cname,
            con_email = cemail,
            con_message = cmsg
        )
        
        con.save()

    template = loader.get_template("contact.html")
    return HttpResponse(template.render(context,request))

def designs(request):
    if 'desi_catid' in request.GET:
        desi_catid =request.GET['desi_catid']
        designs = Design.objects.filter(desi_catid = desi_catid)
    else:
        designs = Design.objects.all().values()
    categories = Category.objects.all().values()
    context = {
         'designs':designs,
         'categories':categories,
    }
    template = loader.get_template("designs.html")
    return HttpResponse(template.render(context,request))

def adddesigns(request):
    if request.method == 'POST':
        desi_name = request.POST["desi_name"]
        desi_price = request.POST["desi_price"]
        desi_image = request.FILES["desi_image"]
        desi_desc = request.POST["desi_desc"]
        desi_catid = request.POST["desi_catid"]

        desi = Design(desiname = desi_name,desiprice = desi_price, desiimage= desi_image, desidesc = desi_desc, desi_catid = desi_catid )
        desi.save()
        return HttpResponseRedirect('/adddesigns')

    cat = Category.objects.all().values()
    context = {
        'cat':cat,
    }

    template = loader.get_template("dashboard/adddesigns.html")
    return HttpResponse(template.render(context,request))

def editdesigns(request,id):
    if request.method == 'POST':
        udesiname = request.POST['udesiname']
        udesi_catid = request.POST['udesi_catid']
        udesiprice = request.POST['udesiprice']
        udesidesc = request.POST['udesidesc']
        desi = Design.objects.filter(id = id) [0]
        desi.desiname = udesiname
        desi.desiprice = udesiprice
        desi.desidesc = udesidesc
        desi.desi_catid = udesi_catid
        if len(request.FILES) !=0:
            udesiimage = request.FILES['udesiimage']
            desi.desiimage= udesiimage
        desi.save()
        return HttpResponseRedirect("/viewdesigns")
    editdesi = Design.objects.filter(id = id)
    cartid = 0
    for x in editdesi:
        catid = x.desi_catid
    cat1 = Category.objects.filter(id = catid)
    cat = Category.objects.all().values()
    context = {
        'editdesi':editdesi,
        'cat':cat,
        'cat1':cat1
    }  
    template = loader.get_template("dashboard/editdesigns.html")
    return HttpResponse(template.render(context,request))

def editcategory(request,id):
    editcat = Category.objects.filter(id = id)
    if request.method == 'POST':
        ucat_name = request.POST['ucat_name']
        cat = Category.objects.filter(id = id)[0]
        cat.cat_name = ucat_name
        if len(request.FILES)!= 0:
            ucat_image = request.FILES['ucat_image']
            cat.cat_image = ucat_image
        cat.save()
        return HttpResponseRedirect("/viewcategory")
    context ={
        'editcat':editcat
    }
    template = loader.get_template("dashboard/editcategory.html")
    return HttpResponse(template.render(context,request))

def addcategory(request):
    if request.method == 'POST':
        cat_name = request.POST['cat_name']
        cat_image = request.FILES['cat_image']

        cat = Category(cat_name =cat_name, cat_image = cat_image)
        cat.save()
        return HttpResponseRedirect('/addcategory')

    template = loader.get_template("dashboard/addcategory.html")
    return HttpResponse(template.render({},request))

def registration(request):
    categories = Category.objects.all().values()
    context ={
        'categories':categories,
    }
    if 'usersession' in request.session:
        return HttpResponseRedirect('/account')
    if request.method == 'POST':
        reg_name = request.POST["registration_name"]
        reg_email = request.POST["registration_email"]
        reg_image = request.FILES["registration_image"]
        reg_phone = request.POST["registration_phone"]
        reg_username= request.POST["registration_username"]
        reg_pwd = request.POST["registration_pwd"]

        registration = Registration(registration_name = reg_name,
                                    registration_email = reg_email,
                                    registration_image = reg_image,
                                    registration_phone = reg_phone,
                                    registration_username = reg_username,
                                    registration_pwd = reg_pwd)
        registration.save()

    template = loader.get_template("registration.html")
    return HttpResponse(template.render(context,request))

    # login
def login(request):
    categories = Category.objects.all().values()
    context ={
        'categories':categories,
    }
    if 'usersession' in request.session:
        return HttpResponseRedirect('/account?home=home')
    if request.method == 'POST':
        log_id = request.POST['log_id']
        log_pwd = request.POST['log_pwd']

        login = Registration.objects.filter(
            registration_username = log_id,
            registration_pwd = log_pwd
        )
        if login:
            request.session['usersession'] = log_id
            cart1 = Cart.objects.filter(cart_user= request.session['usersession'])
            request.session['cart'] = cart1.count()
            wish1 = Wishlist.objects.filter(wish_user = request.session['usersession'])
            request.session['wishlist'] = wish1.count()
            noti1 = Notification.objects.filter(noti_user = request.session['usersession'])
            noti2 = Notification.objects.filter(noti_user = 'All')
            noti3 = noti1.count()+noti2.count()
            request.session['notification'] = noti3
            pro = Registration.objects.filter(registration_username = request.session["usersession"])[0]
            request.session['profile'] = str(pro.registration_image)
            if 'error' in request.session:
                del request.session['error']
            return HttpResponseRedirect('/account?home=home')
        else:
            request.session['error'] = 'msg'
            # return HttpResponseRedirect("/registration")
    template = loader.get_template("login.html")
    return HttpResponse(template.render(context,request))

def logout(request):
    if 'usersession' in request.session:
        del request.session['usersession']
        return HttpResponseRedirect('/login')

def addtocart(request,id):
    categories = Category.objects.all().values()
    if 'usersession' not in request.session:
        return HttpResponseRedirect('/login')
    
    exist = Cart.objects.filter(cart_desiid = id, cart_user = request.session["usersession"])
    if exist:
        exstcart = Cart.objects.filter(cart_desiid = id, cart_user = request.session["usersession"])[0]
        exstcart.cart_qty+=1
        exstcart.cart_amount = exstcart.cart_qty*exstcart.cart_price
        exstcart.save()

    else:
        des = Design.objects.filter(id = id)[0]

        cart = Cart(cart_user = request.session["usersession"],
                    cart_desiid = des.id,
                    cart_name = des.desiname,
                    cart_price = des.desiprice,
                    cart_image = des.desiimage,
                    cart_qty = 1,
                    cart_amount = des.desiprice)
        cart.save()
        context ={
        'categories':categories,
        }
        cart1 = Cart.objects.filter(cart_user= request.session['usersession'])
        request.session['cart'] = cart1.count()
    return HttpResponseRedirect("/cart")

def addtowish(request,id):
    if 'usersession' not in request.session:
        return HttpResponseRedirect('/login')
    user = request.session["usersession"]
    exist = Wishlist.objects.filter(wish_desiid = id, wish_user = user)
    if exist:
        pass
        return HttpResponseRedirect("/wishlist")
    else:
        des = Design.objects.filter(id = id)[0]
        wishlist = Wishlist(wish_user =user,
                            wish_desiid = des.id,
                            wish_name = des.desiname,
                            wish_price = des.desiprice,
                            wish_image = des.desiimage)
        wishlist.save()
        wish1 = Wishlist.objects.filter(wish_user = request.session['usersession'])
        request.session['wishlist'] = wish1.count()
    return HttpResponseRedirect("/wishlist")

def wishlist(request):
    categories = Category.objects.all().values()
    if 'del' in request.GET:
        id =request.GET['del']
        delwish = Wishlist.objects.filter(id = id)[0]
        delwish.delete()
    if 'usersession' not in request.session:
        return HttpResponseRedirect('/login')
    user = request.session["usersession"]
    wish = Wishlist.objects.filter(wish_user = user)
    context = {
        'wish':wish,
        'categories':categories,
    }
    wish1 = Wishlist.objects.filter(wish_user = request.session['usersession'])
    request.session['wishlist'] = wish1.count()
    template = loader.get_template("wishlist.html")
    return HttpResponse(template.render(context,request))

def cart(request):
    categories = Category.objects.all().values()
    if 'usersession' not in request.session:
        return HttpResponseRedirect('/login')
    # delete cart item
    if 'del' in request.GET:
        id =request.GET['del']
        delcart = Cart.objects.filter(id = id)[0]
        delcart.delete()
        cart1 = Cart.objects.filter(cart_user = request.session['usersession'])
        request.session['cart'] = cart1.count()
    #  change cart quantity
    if 'q' in request.GET:
        q = request.GET['q']
        cp = request.GET['cp']
        cart3 = Cart.objects.filter(id=cp)[0]

        if q == 'inc':
            cart3.cart_qty+=1
        elif q == 'dec':
             if(cart3.cart_qty>1):
                cart3.cart_qty-=1   
        cart3.cart_amount = cart3.cart_qty * cart3.cart_price
        cart3.save()
    user = request.session["usersession"]
    cart = Cart.objects.filter(cart_user = user).values()
    cart2 = Cart.objects.filter(cart_user = user)

    tot = 0
    for x in cart2:
        tot+=x.cart_amount
    
    shp = tot * 10/100
    gst = tot * 18/100

    gtot = tot+shp+gst
 
    request.session["tot"] = tot
    request.session["gst"] = gst
    request.session["shp"] = shp
    request.session["gtot"] = gtot

    context = {
        'cart':cart,
        'tot':tot,
        'shp':shp,
        'gst':gst,
        'gtot':gtot,
        'categories':categories,
    }
    cart1 = Cart.objects.filter(cart_user = request.session['usersession'])
    request.session['cart'] = cart1.count()
    template = loader.get_template("cart.html")
    return HttpResponse(template.render(context,request))

def account(request):
    pro = ''
    noti = ''
    notiall = ''
    order = ''
    wish = ''
    odr = ''
    deliveryvalue = 0
    ordercount = 0
    wishorder = 0
    categories = Category.objects.all().values()
    registration_name = Registration.objects.filter(registration_username = request.session["usersession"]
    )
    if 'del1' in request.GET:
        id = request.GET['del1']
        delodr = Order.objects.filter(id = id)[0]
        delodr.delete()
        return HttpResponseRedirect("/account?ord=order")
    if 'usersession' not in request.session:
        return HttpResponseRedirect('/login')
    user = request.session["usersession"]
    if 'pro' in request.GET:
        user = request.session["usersession"]
        pro = Registration.objects.filter(registration_username = user)
    elif 'ord' in request.GET:
        user = request.session["usersession"]
        order = Order.objects.filter(order_user = user)
        ordercount = order.count()
    elif 'noti' in request.GET:
        user = request.session["usersession"]
        noti = Notification.objects.filter(noti_user = user)
        notiall = Notification.objects.filter(noti_user = 'All')
        noti1 = Notification.objects.filter(noti_user = request.session['usersession'])
        noti2 = Notification.objects.filter(noti_user = 'All')
        noti3 = noti1.count()+noti2.count()
        request.session['notification'] = noti3
    elif 'wish' in request.GET:
        user = request.session["usersession"]
        wish = Wishlist.objects.filter(wish_user = user)
        wishorder = wish.count()
    if 'odrsts' in request.GET:
        oid = request.GET["odrsts"]
        odr = Order.objects.filter(id = oid)
        for x in odr:
            if x.delivery_status == 0 :
                deliveryvalue = 0
            if x.delivery_status == 1 :
                deliveryvalue = 34
            if x.delivery_status == 2 :
                deliveryvalue = 65
            if x.delivery_status == 3 :
                deliveryvalue = 100

    if request.method == 'POST':
        rname = request.POST['profile_name']
        remail = request.POST['profile_email']
        reg = Registration.objects.filter(registration_username = user)[0]
        reg.registration_name = rname
        reg.registration_email = remail
        if len(request.FILES) != 0:
            uregistration_image = request.FILES['uregistration_image']
            reg.registration_image = uregistration_image
        reg.save()
        return HttpResponseRedirect("/account?pro")
    if 'del' in request.GET:
        id = request.GET['del']
        delnoti = Notification.objects.filter(id = id)
        delnoti.delete()
    if 'del' in request.GET:
         id = request.GET['del']
         delnoti = Notification1.objects.filter(id = id)
        
    context = {
        'noti':noti,
        'notiall':notiall,
        'pro':pro,
        'order':order,
        'wish':wish,
        'odr':odr,
        'deliveryvalue':deliveryvalue,
        'ordercount':ordercount,
        'wishorder':wishorder,
        'reg': registration_name,
        'categories':categories,
    }
    template = loader.get_template("account.html")
    return HttpResponse(template.render(context,request))

def checkout(request):
    if 'usersession' not in request.session:
        return HttpResponseRedirect('/login')
    co = 0
    adrs = dtype = ''
    #  step4 : After order submit
    if 'dlv_adrs' in request.POST:
        adrs = request.POST['dlv_adrs']
        dtype = request.POST['dlv_type']
        co = 1
    user = request.session["usersession"]

    # step1 : delete old data from orders
    oldodr = Order.objects.filter(order_user = user,order_status = 0)
    oldodr.delete()

    # step2: add cart data to order table
    cart = Cart.objects.filter(cart_user= user)
    for x in cart:
        odr = Order(order_user =x.cart_user,
                    order_name= x.cart_name,
                    order_price = x.cart_price,
                    order_image = x.cart_image,
                    order_qty = x.cart_qty,
                    order_amount = x.cart_amount,
                    order_address = adrs,
                    order_dlvtype = dtype,
                    order_status = 0)
        odr.save()

    #  step3: Display Order data
    order = Order.objects.filter(order_user = user,order_status = 0) .values()
    tot = request.session["tot"]
    gst = request.session["gst"]
    shp = request.session["shp"]
    gtot= request.session["gtot"]

    context = {
        'order':order,
        'tot':tot,
        'shp':shp,
        'gst':gst,
        'gtot':gtot,
        'co':co,
     }
    template = loader.get_template("checkout.html")
    return HttpResponse(template.render(context,request))

def confirmorder(request):
    categories = Category.objects.all().values()
    context = {
        'categories':categories,
    }
    user =  request.session["usersession"]
    order = Order.objects.filter(order_user = user, order_status=0)
    for x in order:
        x.order_status = 1
        x.save()

    cartdel = Cart.objects.filter(cart_user = user)
    cartdel.delete()
    template = loader.get_template("confirmorder.html")
    return HttpResponse(template.render(context,request))

def myorder(request):
    categories = Category.objects.all().values()

    user = request.session["usersession"]
    order = Order.objects.filter(order_user = user, order_status=1)
    context = {
        'categories':categories,
        'order':order,
    }    
    template = loader.get_template("myorder.html")
    return HttpResponse(template.render(context,request))

def adminlogin(request):
    if request.method == 'POST':
        admin_name = request.POST['admin_name']
        admin_pwd = request.POST['admin_pwd']
        adminlogin = Adminregistration.objects.filter(
            admin_user = admin_name,
            admin_pwd = admin_pwd
        )
        if adminlogin:
            request.session['adminsession'] = admin_name
            if 'error' in request.session:
                del request.session['error']    
            return HttpResponseRedirect('/adddesigns')
        else:
            request.session['error'] = 'msg'
    template = loader.get_template("dashboard/adminlogin.html")
    return HttpResponse(template.render({},request))

def adminlogout(request):
    if 'adminsession' in request.session:
        del request.session['adminsession']
        return HttpResponseRedirect('/adminlogin')

def viewcategory(request):
    category = Category.objects.all().values()
    context = {
        'category':category,
    }
    template = loader.get_template("dashboard/viewcategory.html")
    return HttpResponse(template.render(context,request))

def viewdesigns(request):
    designs = Design.objects.all().values()
    context = {
        'designs': designs,
    }
    template = loader.get_template("dashboard/viewdesigns.html")
    return HttpResponse(template.render(context,request))
        

def vieworders(request):
    orders = Order.objects.filter(order_status = 1)
    context = {
        'orders': orders,
    }
    template = loader.get_template("dashboard/vieworders.html")
    return HttpResponse(template.render(context,request))


def vieworders1(request,id):
    if 'status' in request.POST:
        status = request.POST['status']
        odr = Order.objects.filter(id = id)[0]
        if status == '0':
            odr.process_date = datetime.datetime.now()
            odr.delivery_status = 0
        elif status == '1':
            odr.ship_date = datetime.datetime.now()
            odr.delivery_status = 1
        elif status == '2':
            odr.out_date = datetime.datetime.now()
            odr.delivery_status = 2
        elif status == '3':
            odr.delivered_date = datetime.datetime.now()
            odr.delivery_status = 3
        odr.save()
        return  HttpResponseRedirect("/vieworders")
    orders = Order.objects.filter(order_status = 1)
    context = {
        'orders':orders,
    }
    template = loader.get_template("dashboard/vieworders.html")
    return HttpResponse(template.render(context,request))

def addnotification(request):
    if request.method == 'POST':
        notification = request.POST['notification']
        name = request.POST['noti_name']
        date = datetime.datetime.now()
        notiuser= request.POST['notiuser']
        noti = Notification(noti_message = notification, noti_date = date, noti_name = name, noti_user = notiuser)
        noti.save()
        noti1 = Notification1(noti_message = notification, noti_date = date, noti_name = name, noti_user = notiuser)
        noti1.save()
        noti1 = Notification.objects.filter(noti_user = request.session['usersession'])
        noti2 = Notification.objects.filter(noti_user = 'All')
        noti3 = noti1.count()+noti2.count()
        request.session['notification'] = noti3
        return HttpResponseRedirect("/addnotification")

    reg = Registration.objects.all().values()
    context = {
        'reg':reg
    }
    template = loader.get_template("dashboard/addnotification.html")
    return HttpResponse(template.render(context,request))

def viewnotification(request):
    if 'del' in request.GET:
        id = request.GET['del']
        delnoti = Notification.objects.filter(id = id)
        delnoti.delete()
    if request.method == 'POST':
        notify = request.POST['notify']
        if notify  == 'one':
            if 'twosession' in request.session:
                del request.session['twosession']
            noti = Notification.objects.all().values()
        elif notify == 'two':
            request.session['twosession'] = 'two'
            noti = Notification1.objects.all().values()
    else:
        if 'twosession' in request.session:
                   del request.session['twosession']
        noti = Notification.objects.all().values()
    
    context = {
        'noti': noti
    }
    template = loader.get_template("dashboard/viewnotification.html")
    return HttpResponse(template.render(context,request))

def editnotification(request,id):
    noti = Notification.objects.filter(id = id) [0]
    if request.method == 'POST':
        unoti_name = request.POST['unoti_name'] 
        unoti_user = request.POST['unoti_user']
        unoti_message = request.POST['unoti_message']
        noti.noti_name = unoti_name
        noti.noti_user = unoti_user
        noti.noti_message = unoti_message
        noti.save()
        return HttpResponseRedirect("/viewnotification")
    editnoti = Notification.objects.filter(id = id)
    context ={
        'editnoti': editnoti,
        'reg': Registration.objects.all()
    }
    template = loader.get_template("dashboard/editnotification.html")
    return HttpResponse(template.render(context,request))