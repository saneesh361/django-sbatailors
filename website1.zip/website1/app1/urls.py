from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',views.index,name='index'),
    path('about',views.about,name='about'),
    path('contact',views.contact,name='contact'),
    path('designs',views.designs,name='designs'),
    path('addtowish/<int:id>',views.addtowish,name='addtowish'),
    path('addtocart/<int:id>',views.addtocart,name='addtocart'),
    path('wishlist',views.wishlist,name='wishlist'),
    path('cart',views.cart,name='cart'),
    path('registration',views.registration,name='registration'),
    path('login',views.login,name='login'),
    path('account',views.account,name='account'),
    path('registration',views.registration,name='registration'),
    path('logout',views.logout,name='logout'),
    path('checkout',views.checkout,name='checkout'),
    path('confirmorder',views.confirmorder,name='confirmorder'),
    path('myorder',views.myorder,name='myorder'),
    



# admin
    path('adddesigns',views.adddesigns,name='adddesigns'),
    path('addcategory',views.addcategory,name='addcategory'),
    path('addnotification',views.addnotification,name='addnotification'),
    path('viewcategory',views.viewcategory,name='viewcategory'),
    path('viewdesigns',views.viewdesigns,name='viewdesigns'),
    path('viewnotification',views.viewnotification,name='viewnotification'),
    path('vieworders',views.vieworders,name='vieworders'),
    path('vieworders/<int:id>',views.vieworders1,name='vieworders'),
    path('editdesigns/<int:id>',views.editdesigns,name='editdesigns'),
    path('editcategory/<int:id>',views.editcategory,name='editcategory'),
    path('editnotification/<int:id>',views.editnotification,name='editnotification'),
    path('adminlogin',views.adminlogin,name='adminlogin'),
    path('adminlogout',views.adminlogout,name='adminlogout'),
]
urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)