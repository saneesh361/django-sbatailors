document.getElementById('demo').innerHTML="Welcome to ABC Company";
document.getElementById('demo').style.color="white";


